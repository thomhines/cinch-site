
document.addEventListener('DOMContentLoaded',function(){	
	document.querySelector(".js.fail").style.display='none';
	document.querySelector(".js.success").style.display='block';
});



$(function() {
	
	$('.jquery.success').show();
	$('.jquery.fail').hide();
	
});