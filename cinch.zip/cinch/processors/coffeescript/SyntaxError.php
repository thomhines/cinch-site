<?php

namespace CoffeeScript;

Init::init();

class SyntaxError extends Error {}

?>
